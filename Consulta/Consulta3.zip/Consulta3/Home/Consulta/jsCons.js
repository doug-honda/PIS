function calculo(){
    let teorAlc = (document.getElementById("teor").value);
    let vol = (document.getElementById("vol").value);
    let peso = (document.getElementById("peso").value);
    let indice = ((vol*teorAlc*0.8)/(peso*0.6)).toFixed(2);

    document.getElementById("resultado").innerHTML = "A concentração é de: " + indice + "mg/dl"

    let recomendacoes = document.getElementById("recomendacoes");
    if (indice>20){
        recomendacoes.innerHTML =
            "<p> Beba mais devagar, os sintomas de embriaguez podem começar a vir a tona, dê uma pausa e beba um copo de água</p>"
    }
    if (indice>150){
        recomendacoes.innerHTML =
            "<p>  Dê uma pausa , de em torno 15 minutos, neste meio tempo beba água</p>"
    }
    if (indice<20){
        recomendacoes.innerHTML = "Beba com moderação!" ;
    }
}
